import stripe
from flask import redirect, render_template, request, session
# This is your test secret API key.
stripe.api_key = 'sk_test_51MEjVPCNqiJJPk1cZP1h93wFBdqqrcoXzdmXWmD42JfqrLbywYZJpKiVTwqMwaekvywhlWFT7KyeSDBBTY7DZ2hm00wtm1LStC'
from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models.scone import Scone
from flask_app.models.user import User
# Dashboard and controlling all things past user login and reg should be controlled here.
#Most app routes will be put here if they are involving object user is interacting with.

@app.route('/mainpage')
def dashboard():
    return render_template('mainpage.html')

@app.route('/login')
def loginregister():
    return render_template('login.html')

@app.route('/account')
def account():
    return render_template('account.html')

@app.route('/order')
def order():
    return render_template('order.html')

@app.route('/about')
def about():
    return render_template('about.html')

#@app.route('/form/order')

@app.route('/cart')
def cart():
    if 'user.id' not in session:
        return redirect('/login')
    return render_template('cart.html')

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    try:
        checkout_session = stripe.checkout.Session.create(
            line_items=[
                {
                    # Provide the exact Price ID (for example, pr_1234) of the product you want to sell
                    'price': '{{PRICE_ID}}',
                    'quantity': 1,
                },
            ],
            mode='payment',
            success_url= 'localhost:5000/success.html',
            cancel_url="localhost:5000/cancel.html",
            automatic_tax={'enabled': True},
        )
    except Exception as e:
        return str(e)

    return redirect(checkout_session.url, code=303)

#@app.route ('/order/post', methods=['POST'])
