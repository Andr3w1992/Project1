from flask_app.models.user import User
from flask import flash
from flask_app.config.mysqlconnection import connectToMySQL


db = 'bakery_db'

class Scone:
    def __init__( self , data ):
        self.id = data['id']
        self.type = data['type']
        self.how_many = data['how_many']
        self.add_comment = data['add_comment']
        self.delivery_address = data['delivery_address']
        self.cust_phone = data['cust_phone']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']
        self.PRICE_ID = data['PRICE_ID']
        self.creator = None

    @classmethod
    def create_scone(cls,data):
        query = """
            INSERT INTO scone (type, how_many, cust_phone, add_comment, delivery_address, PRICE_ID, user_id)
            VALUES(%(type)s,%(how_many)s,%(cust_phone)s,%(add_comment)s,%(delivery_address)s, %(PRICE_ID)s,%(user_id)s);
            """
        return connectToMySQL(db).query_db(query,data)